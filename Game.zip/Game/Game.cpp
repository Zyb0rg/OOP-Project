#include "Game.h"
#include "TextureManager.h"

SDL_Event Game::evnt;

Game::Game()
{
	
	width = 800;
	height = 640;
	window = NULL;
	renderer = NULL;
	isRunning = true;
	flag = 0;
	yVelocity = 0;
	gravity = 2.3;
	firstTick = SDL_GetTicks();
}

Game::~Game()
{

}

bool Game::IsRunning()
{
	return isRunning;
}

void Game::Init()
{
	if (SDL_Init(SDL_INIT_EVERYTHING)==0)
	{
		cout << "Initialization done!" << endl;
		window = SDL_CreateWindow("Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, width, height, SDL_WINDOW_RESIZABLE);
		if (window)
		{
			cout << "Window created !" << endl;
			renderer = SDL_CreateRenderer(window,-1,0);
			if (renderer)
			{
				cout << "Renderer created !" << endl;
				SDL_SetRenderDrawColor(renderer, 150, 255, 255, 255);
				isRunning = true;
				player1 = TextureManager::Texture("assets/6.png", renderer);
				player2 = TextureManager::Texture("assets/7.png", renderer);
			}
		}
	}
	
}

void Game::EventHandling()
{
	SDL_PollEvent(&evnt);

	if (Game::evnt.type == SDL_QUIT)
	{
		isRunning = false;
	}

	else if (Game::evnt.type == SDL_KEYDOWN)
	{
		switch (Game::evnt.key.keysym.sym)
		{
		case SDLK_UP:
			dt = 0;
			updtTick = SDL_GetTicks();
			firstTick = updtTick;
			Jump();
		default:
			break;
		}
		
	}
	else
	{
		dt = SDL_GetTicks() - firstTick;
		dt = dt * 0.004;
		cout << dt << endl;
		if (dt <= 0.5)
		{
			dt = 0.5;
		}
		if (dt >= 8)
		{
			dt = 8;
		}
		yVelocity = yVelocity + (gravity * dt);
	}
}

void Game::Jump()
{
	yVelocity -= 6;
}

void Game::Update()
{

	src.w = 80;
	src.h = 60;
	src.x = src.y = 0;

	dest.w = 60;
	dest.h = 40;
	dest.x = 10;
	dest.y = yVelocity + 320;
}

bool Game::Switcher()
{
	if (flag == 0)
	{
		flag = 1;
		return true;
	}
	if (flag == 1)
	{
		flag = 0;
		return false;
	}
}

void Game::Render()
{
	SDL_RenderClear(renderer);
	SDL_RenderCopyEx(renderer, SDL_GetTicks() % 400 > 200 ? player1 : player2, & src, & dest, yVelocity * 0.1 , nullptr, SDL_FLIP_NONE);
	SDL_RenderPresent(renderer);
}

void Game::Clear()
{
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
	SDL_Quit();
}
