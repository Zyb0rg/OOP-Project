#include "Game.h"
#include "TextureManager.h"

SDL_Texture* TextureManager::Texture(const char* filename,SDL_Renderer* ren)
{
	SDL_Surface* surface = IMG_Load(filename);
	SDL_Texture* tex = SDL_CreateTextureFromSurface(ren, surface);
	SDL_FreeSurface(surface);
	return tex;
}