#pragma once
#include "Game.h"

class TextureManager
{

public:
	static SDL_Texture* Texture(const char* title,SDL_Renderer* ren);
};