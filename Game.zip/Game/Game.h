#pragma once
#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
using namespace std;

class Game
{
	int flag;
	int x;
	double yVelocity;
	int width;
	int height;
	int acc;
	double gravity;
	bool isRunning;
	float dt;
	static SDL_Event evnt;
	Uint32 firstTick;
	Uint32 updtTick;
	SDL_Window* window;
	SDL_Renderer* renderer;
	SDL_Texture* player1;
	SDL_Texture* player2;
	SDL_Rect src, dest;
	
public:
	Game();
	~Game();
	bool IsRunning();
	bool Switcher();
	void Init();
	void EventHandling();
	void Update();
	void Render();
	void Clear();
	void Jump();
};