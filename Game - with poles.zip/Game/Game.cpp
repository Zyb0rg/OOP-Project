#include "Game.h"
#include "TextureManager.h"

SDL_Event Game::evnt;

Game::Game()
{
	
	width = 800;
	height = 640;
	window = NULL;
	renderer = NULL;
	isRunning = true;
	flag = 0;
	yVelocity = 0;
	gravity = 2.3;
	firstTick = SDL_GetTicks();
	timer = 0;
}

Game::~Game()
{

}

bool Game::IsRunning()
{
	return isRunning;
}

void Game::Init()
{
	if (SDL_Init(SDL_INIT_EVERYTHING)==0)
	{
		cout << "Initialization done!" << endl;
		window = SDL_CreateWindow("Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, width, height, SDL_WINDOW_RESIZABLE);
		if (window)
		{
			cout << "Window created !" << endl;
			renderer = SDL_CreateRenderer(window,-1,0);
			if (renderer)
			{
				cout << "Renderer created !" << endl;
				SDL_SetRenderDrawColor(renderer, 150, 255, 255, 255);
				isRunning = true;
				player1 = TextureManager::Texture("assets/6.png", renderer);
				player2 = TextureManager::Texture("assets/7.png", renderer);
				poles = TextureManager::Texture("assets/3.png", renderer);
				poles1 = TextureManager::Texture("assets/3.png", renderer);
				poles2 = TextureManager::Texture("assets/3.png", renderer);
				poles3 = TextureManager::Texture("assets/3.png", renderer);
				poles4 = TextureManager::Texture("assets/3.png", renderer);
				poles5 = TextureManager::Texture("assets/3.png", renderer);
			}
		}
	}
	
}

void Game::EventHandling()
{
	SDL_PollEvent(&evnt);

	if (Game::evnt.type == SDL_QUIT)
	{
		isRunning = false;
	}

	else if (Game::evnt.type == SDL_KEYDOWN)
	{
		switch (Game::evnt.key.keysym.sym)
		{
		case SDLK_UP:
			dt = 0;
			updtTick = SDL_GetTicks();
			firstTick = updtTick;
			Jump();
		default:
			break;
		}
		
	}
	else
	{
		dt = SDL_GetTicks() - firstTick;
		dt = dt * 0.004;
		//cout << dt << endl;
		if (dt <= 0.5)
		{
			dt = 0.5;
		}
		if (dt >= 8)
		{
			dt = 8;
		}
		yVelocity = yVelocity + (gravity * dt);
	}
}

void Game::Jump()
{
	yVelocity -= 6;
}

void Game::Update()
{
	// Bird rect
	src.w = 80;
	src.h = 60;
	src.x = src.y = 0;

	dest.w = 60;
	dest.h = 40;
	dest.x = 10;
	dest.y = yVelocity + 320;

	
	//pole rect
	pSrc.x = pSrc.y = 0;
	pSrc.w = 80;
	pSrc.h = 434;

	pDest.w = 80;
	pDest.h = 434;
	cnt -= 2;
	pDest.x = 550 + cnt;
	pDest.y = 400;

	//repeating pole
	if (pDest.x < -80)
	{
		//pDest.x = 900;
		cnt = 300;
	}

	//pole1 rect
	p1Src.x = p1Src.y = 0;
	p1Src.w = 80;
	p1Src.h = 434;

	p1Dest.w = 80;
	p1Dest.h = 434;
	cnt1 -= 2;
	p1Dest.x = 800 + cnt1;
	p1Dest.y = 400;

	//repeating pole1
	if (p1Dest.x < -80)
	{
		cnt1 = 50;
	}

	//pole2 rect
	p2Src.x = p2Src.y = 0;
	p2Src.w = 80;
	p2Src.h = 434;

	p2Dest.w = 80;
	p2Dest.h = 434;
	cnt2 -= 2;
	p2Dest.x = 1050 + cnt2;
	p2Dest.y = 400;

	//repeating pole2
	if (p2Dest.x < -80)
	{
		cnt2 = -200;
	}

	
	//pole3 rect
	p3Src.x = p3Src.y = 0;
	p3Src.w = 80;
	p3Src.h = 434;

	p3Dest.w = 80;
	p3Dest.h = 434;
	cnt3 -= 2;
	p3Dest.x = 1050 + cnt3;
	p3Dest.y = -190;

	//repeating pole3
	if (p3Dest.x < -80)
	{
		cnt3 = -200;
	}

	//pole4 rect
	p4Src.x = p4Src.y = 0;
	p4Src.w = 80;
	p4Src.h = 434;

	p4Dest.w = 80;
	p4Dest.h = 434;
	cnt4 -= 2;
	p4Dest.x = 800 + cnt4;
	p4Dest.y = -190;

	//repeating pole4
	if (p4Dest.x < -80)
	{
		cnt4 = 50;
	}

	//pole5 rect
	p5Src.x = p5Src.y = 0;
	p5Src.w = 80;
	p5Src.h = 434;

	p5Dest.w = 80;
	p5Dest.h = 434;
	cnt5 -= 2;
	p5Dest.x = 550 + cnt5;
	p5Dest.y = -190;

	//repeating pole5
	if (p5Dest.x < -80)
	{
		cnt5 = 300;
	}
}

bool Game::Switcher()
{
	if (flag == 0)
	{
		flag = 1;
		return true;
	}
	if (flag == 1)
	{
		flag = 0;
		return false;
	}
}

void Game::Render()
{
	SDL_RenderClear(renderer);
	SDL_RenderCopyEx(renderer, SDL_GetTicks() % 400 > 200 ? player1 : player2, & src, & dest, yVelocity * 0.1 , nullptr, SDL_FLIP_NONE);
	SDL_RenderCopy(renderer,poles, &pSrc, &pDest);
	SDL_RenderCopy(renderer, poles1, &p1Src, &p1Dest);
	SDL_RenderCopy(renderer, poles2, &p2Src, &p2Dest);
	SDL_RenderCopy(renderer, poles3, &p3Src, &p3Dest);
	SDL_RenderCopy(renderer, poles4, &p4Src, &p4Dest);
	SDL_RenderCopy(renderer, poles5, &p5Src, &p5Dest);
	SDL_RenderPresent(renderer);
}

void Game::Clear()
{
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
	SDL_Quit();
}
