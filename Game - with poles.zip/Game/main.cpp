#include "Game.h"

Game* game = new Game;

int main(int argc,char** argv)
{
	const int FPS = 60;
	Uint32 startTime;
	int timerFps;
	game->Init();
	int SDL_EnableKeyRepeat(int delay, int interval);



	while (game->IsRunning())
	{
		startTime = SDL_GetTicks();

		game->EventHandling();
		game->Update();
		game->Render();

		timerFps = SDL_GetTicks() - startTime;
		if (timerFps < (1000/ FPS))
		{
			SDL_Delay((1000 / FPS) - timerFps);
		}
	}
	game->Clear();

	return 0;
}