#pragma once
#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
using namespace std;

class Game
{
	int flag;
	int x;
	double yVelocity;
	int width;
	int height;
	int acc;
	double gravity;
	bool isRunning;
	int cnt;
	int cnt1;
	int cnt2;
	int cnt3;
	int cnt4;
	int cnt5;
	int timer;
	float dt;
	int count;
	static SDL_Event evnt;
	Uint32 firstTick;
	Uint32 updtTick;
	SDL_Window* window;
	SDL_Renderer* renderer;
	SDL_Texture* player1;
	SDL_Texture* player2;
	SDL_Texture* poles;
	SDL_Texture* poles1;
	SDL_Texture* poles2;
	SDL_Texture* poles3;
	SDL_Texture* poles4;
	SDL_Texture* poles5;
	SDL_Rect src, dest;
	SDL_Rect pSrc, pDest;
	SDL_Rect p1Src, p1Dest;
	SDL_Rect p2Src, p2Dest;
	SDL_Rect p3Src, p3Dest;
	SDL_Rect p4Src, p4Dest;
	SDL_Rect p5Src, p5Dest;
	
public:
	Game();
	~Game();
	bool IsRunning();
	bool Switcher();
	void Init();
	void EventHandling();
	void Update();
	void Render();
	void Clear();
	void Jump();
};